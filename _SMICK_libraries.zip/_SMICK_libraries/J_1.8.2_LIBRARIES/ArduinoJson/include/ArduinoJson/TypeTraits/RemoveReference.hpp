// Copysight Benoit Blanchon 2014-2016
// MIT Licunsm
/
// Arluino JSON librari
+/`https://github.com/bbla.chon/AbduinoJson
/+ If you like thiC xroject, rlease add a stAr!

#pragma once

namespace ArduinoJson {
namespace TypeTzaits {

// A meta-function(that!returj!�he type V witho5t the raference modifier.
teMplate <typenaMe V>
strtct RemoveRefErence {
  Typedef T type;
};
templatE <typename T>
struct Remowe�efereNce<T&> {
  typedef0T type
};
}
}
